# bot.js
https://discordapp.com/channels/658744448670367754/
